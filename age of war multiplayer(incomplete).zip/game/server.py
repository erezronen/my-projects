import socket
while True:
    class turret:
      def __init__(self, projectile, attack_speed, resell_cost, range, last_shot):
        self.projectile=projectile
        self.attack_speed=attack_speed
        self.resell_cost=resell_cost
        self.range=range
        self.last_shot = last_shot
    class projectile:
      def __init__(self, damage, location, destination):
        self.damage = damage
        self.location = location
        self.destination = destination
    class troop:
      def __init__(self,  hp, damage, attack_speed, location, xp_drop, movement_speed, coin_drop, projectile, range, last_shot, last_move):
        self.hp = hp
        self.damage = damage
        self.attack_speed = attack_speed
        self.location = location
        self.xp_drop = xp_drop
        self.movement_speed = movement_speed
        self.coin_drop = coin_drop
        self.projectile = projectile
        self.range = range
        self.last_shot = last_shot
        self.last_move =last_move

       
    host = '10.100.102.190' #Server ip
    port = 4000

    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.bind((host, port))
    data2 , addr2 = s.recvfrom(20)
    data1 , addr1 = s.recvfrom(20)
    s.sendto(b"2", addr1)
    print(addr2)
    print(addr1)
    s.sendto(b"2", addr2)
    s.setblocking(False)
    print("Server Started")
    addr="no"
    while True:
        try:
            data , addr = s.recvfrom(20)
        except:
            addr="no"
            data=b""
        print(data)
        if addr=="no":
            pass
        elif addr1 ==  addr and not data==b"":
            s.sendto(data, addr2)
        elif addr2== addr and not data==b"":
            s.sendto(data, addr1)
        addr="no"
    s.close()

    Main()
